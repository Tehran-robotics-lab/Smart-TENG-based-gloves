var searchData=
[
  ['transposeddirectformii_86',['TransposedDirectFormII',['../classIir_1_1TransposedDirectFormII.html',1,'Iir']]],
  ['twopole_87',['TwoPole',['../structIir_1_1Custom_1_1TwoPole.html',1,'Iir::Custom']]]
];
