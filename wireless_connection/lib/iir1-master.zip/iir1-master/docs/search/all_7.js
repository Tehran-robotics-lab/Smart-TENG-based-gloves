var searchData=
[
  ['butterworth_40',['Butterworth',['../namespaceIir_1_1Butterworth.html',1,'Iir']]],
  ['chebyshevi_41',['ChebyshevI',['../namespaceIir_1_1ChebyshevI.html',1,'Iir']]],
  ['chebyshevii_42',['ChebyshevII',['../namespaceIir_1_1ChebyshevII.html',1,'Iir']]],
  ['custom_43',['Custom',['../namespaceIir_1_1Custom.html',1,'Iir']]],
  ['iir_44',['Iir',['../namespaceIir.html',1,'']]],
  ['iirnotch_45',['IIRNotch',['../structIir_1_1RBJ_1_1IIRNotch.html',1,'Iir::RBJ']]],
  ['ismatchedpair_46',['isMatchedPair',['../structIir_1_1ComplexPair.html#a79d121320c8b042faebcc0364398b071',1,'Iir::ComplexPair']]]
];
