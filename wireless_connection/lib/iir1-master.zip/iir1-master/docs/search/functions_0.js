var searchData=
[
  ['applyscale_144',['applyScale',['../classIir_1_1Biquad.html#a38c8e327dca53dbfa9a25758b7be8227',1,'Iir::Biquad']]]
];
